package net.petersgaming.powerssmp;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.server.level.ServerLevel;
import java.util.List;
import java.util.function.Consumer;

public final class PowersSmp implements ModInitializer {
    public static final String MOD_ID = "powers_smp";

    public static final Item FIRE_SWORD = register("fire_sword",
        new PowerSword(ToolMaterial.NETHERITE, 7, -2.4f, Power.FIRE, new Item.Properties().fireResistant()));
    public static final Item LIGHTNING_SWORD = register("lightning_sword",
        new PowerSword(ToolMaterial.NETHERITE, 6, -2.4f, Power.LIGHTNING, new Item.Properties().fireResistant()));
    public static final Item SHADOW_SWORD = register("shadow_sword",
        new PowerSword(ToolMaterial.DIAMOND, 6, -2.3f, Power.SHADOW, new Item.Properties()));
    public static final Item ICE_SWORD = register("ice_sword",
        new PowerSword(ToolMaterial.DIAMOND, 6, -2.4f, Power.ICE, new Item.Properties()));
    public static final Item GRAVITY_SWORD = register("gravity_sword",
        new PowerSword(ToolMaterial.NETHERITE, 5, -2.5f, Power.GRAVITY, new Item.Properties().fireResistant()));

    private static Item register(String id, Item item) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(MOD_ID, id));
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(entries -> {
            entries.accept(FIRE_SWORD);
            entries.accept(LIGHTNING_SWORD);
            entries.accept(SHADOW_SWORD);
            entries.accept(ICE_SWORD);
            entries.accept(GRAVITY_SWORD);
        });
    }

    public enum Power { FIRE, LIGHTNING, SHADOW, ICE, GRAVITY }

    public static final class PowerSword extends SwordItem {
        private final Power power;
        private int hitCount = 0;
        public PowerSword(ToolMaterial material, int attackDamage, float attackSpeed, Power power, Item.Properties props) {
            super(material, attackDamage, attackSpeed, props);
            this.power = power;
        }

        @Override
        public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            boolean result = super.hurtEnemy(stack, target, attacker);
            if (attacker.level().isClientSide()) return result;
            switch (power) {
                case FIRE -> {
                    target.setSecondsOnFire(3);
                    target.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 0));
                    target.hurt(attacker.damageSources().onFire(), 1.0f);
                }
                case LIGHTNING -> {
                    hitCount++;
                    if (hitCount >= 4 && attacker.level() instanceof ServerLevel server) {
                        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(server, EntitySpawnReason.TRIGGERED);
                        if (bolt != null) {
                            bolt.moveTo(target.getX(), target.getY(), target.getZ());
                            server.addFreshEntity(bolt);
                        }
                        hitCount = 0;
                    }
                }
                case SHADOW -> target.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 50, 0));
                case ICE -> target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 1));
                case GRAVITY -> {
                    Vec3 pull = attacker.position().subtract(target.position()).normalize().scale(0.55);
                    target.push(pull.x, 0.22, pull.z);
                    target.hurtMarked = true;
                }
            }
            return result;
        }

        @Override
        public InteractionResult useOn(UseOnContext context) {
            Player player = context.getPlayer();
            Level level = context.getLevel();
            if (player == null || level.isClientSide()) return InteractionResult.PASS;
            long now = level.getGameTime();
            long last = player.getPersistentData().getLong("powers_smp_cd_" + power.name());
            if (now - last < 100) {
                player.displayClientMessage(Component.literal("Ability cooldown: " + (100 - (now - last))/20 + "s"), true);
                return InteractionResult.SUCCESS;
            }
            player.getPersistentData().putLong("powers_smp_cd_" + power.name(), now);
            switch (power) {
                case FIRE -> {
                    for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(3))) {
                        if (e != player) e.setSecondsOnFire(3);
                    }
                }
                case LIGHTNING -> {
                    if (level instanceof ServerLevel server) {
                        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(server, EntitySpawnReason.TRIGGERED);
                        if (bolt != null) {
                            bolt.moveTo(context.getClickLocation().x, context.getClickLocation().y, context.getClickLocation().z);
                            server.addFreshEntity(bolt);
                        }
                    }
                }
                case SHADOW -> {
                    player.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 60, 0));
                    player.addEffect(new MobEffectInstance(MobEffects.SPEED, 80, 1));
                }
                case ICE -> {
                    for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(4))) {
                        if (e != player) e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 80, 2));
                    }
                }
                case GRAVITY -> {
                    for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(6))) {
                        if (e != player) {
                            Vec3 pull = player.position().subtract(e.position()).normalize().scale(0.8);
                            e.push(pull.x, 0.25, pull.z);
                            e.hurtMarked = true;
                        }
                    }
                }
            }
            player.getCooldowns().addCooldown(this, 100);
            player.displayClientMessage(Component.literal(power.name() + " ability activated!"), true);
            return InteractionResult.SUCCESS;
        }
    }
}
